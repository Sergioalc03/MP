#ifndef FUNCIONES_H
#define FUNCIONES_H

void combinaFicheros(char *fileA, char *fileB, char *name);

#endif //FUNCIONES_H